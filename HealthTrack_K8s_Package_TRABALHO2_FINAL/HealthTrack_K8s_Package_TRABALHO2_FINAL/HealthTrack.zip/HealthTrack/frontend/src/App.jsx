import React, { useEffect, useState } from 'react'

// --- Notificações simples (substitui alert) ---
const useToast = () => {
  const [toast, setToast] = useState(null)
  const notify = (text, type='info', timeout=4000) => {
    setToast({ text, type })
    if (timeout) setTimeout(() => setToast(null), timeout)
  }
  return { toast, notify }
}


// --- CORREÇÃO DEFINITIVA DOS BOTÕES ---
const BACKEND = '/api' // Isso usa o proxy Nginx (que corrigimos)

const ESPECIALIDADES = [
  "Clínico Geral",
  "Cardiologia",
  "Dermatologia",
  "Ginecologia",
  "Neurologia",
  "Ortopedia",
  "Oftalmologia",
  "Pediatria",
  "Psiquiatria",
  "Urologia"
]

const gerarHorariosFuturos = () => {
  const slots = []
  const agora = new Date()

  for (let addDia = 0; addDia <= 30; addDia++) {
    const base = new Date(agora.getFullYear(), agora.getMonth(), agora.getDate() + addDia)
    for (let h = 8; h <= 18; h++) {
      const dt = new Date(base.getFullYear(), base.getMonth(), base.getDate(), h, 0, 0)
      slots.push(dt.toISOString())
    }
  }
  return slots
}

// --- FUNÇÃO DE MÁSCARA DE TELEFONE ---
const aplicarMascaraTelefone = (valor) => {
  let v = valor.replace(/\D/g, '').substring(0, 11); 

  if (v.length > 10) {
    v = v.replace(/^(\d{2})(\d{5})(\d{4})$/, '($1) $2-$3');
  } else if (v.length > 6) {
    v = v.replace(/^(\d{2})(\d{5})(\d{0,4})$/, '($1) $2-$3');
  } else if (v.length > 2) {
    v = v.replace(/^(\d{2})(\d{0,5})$/, '($1) $2');
  } else if (v.length > 0) {
    v = v.replace(/^(\d{0,2})$/, '($1');
  }
  return v;
}
// --- FIM DA FUNÇÃO ---


export default function App() {
  const { toast, notify } = useToast()

  const [pacientes, setPacientes] = useState([]) // Inicia como array vazio
  const [consultas, setConsultas] = useState([]) // Inicia como array vazio

  const [p, setP] = useState({ nome: '', idade: '', email: '', telefone: '' })
  const [c, setC] = useState({ paciente_id: '', data_consulta: '', medico: '', observacao: '' })

  const horarios = gerarHorariosFuturos()

  // --- FUNÇÃO CARREGAR ROBUSTA (Evita tela em branco) ---
  const carregar = async () => {
    try {
      // Agora, isso vai chamar /api/pacientes e /api/consultas
      const respPacientes = await fetch(`${BACKEND}/pacientes`);
      if (!respPacientes.ok) {
        throw new Error(`Erro ao buscar pacientes: ${respPacientes.statusText}`);
      }
      const ps = await respPacientes.json();
      setPacientes(Array.isArray(ps) ? ps : []); // Garante que é um array

      const respConsultas = await fetch(`${BACKEND}/consultas`);
      if (!respConsultas.ok) {
        throw new Error(`Erro ao buscar consultas: ${respConsultas.statusText}`);
      }
      const cs = await respConsultas.json();
      setConsultas(Array.isArray(cs) ? cs : []); // Garante que é um array

    } catch (err) {
      console.error("Falha ao carregar dados:", err);
      notify(`Falha ao carregar dados do backend. Verifique os logs dos pods 'backend' e 'database'.\n\n${err.message}`, 'error');
      setPacientes([]);
      setConsultas([]);
    }
  }
  // --- FIM DA FUNÇÃO ---

  useEffect(() => { carregar() }, [])

  const addPaciente = async (e) => {
    e.preventDefault()

    // Validação de E-mail
    if (p.email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(p.email)) {
        notify('Por favor, insira um formato de e-mail válido (ex: nome@dominio.com)', 'error');
      return;
      }
    }
    // Validação de Telefone
    if (p.telefone && p.telefone.replace(/\D/g, '').length < 10) {
        notify('Por favor, insira um telefone válido (ex: (11) 98765-4321).', 'error');
      return;
    }

    const resp = await fetch(`${BACKEND}/pacientes`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...p, idade: p.idade ? Number(p.idade) : null })
    })
    if (!resp.ok) { notify('Erro ao salvar paciente. O backend está rodando?', 'error'); return }
    setP({ nome: '', idade: '', email: '', telefone: '' })
    notify('Paciente salvo com sucesso!', 'success');
    await carregar()
  }

  const addConsulta = async (e) => {
    e.preventDefault()
    const payload = { ...c }
    const resp = await fetch(`${BACKEND}/consultas`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    })
    if (!resp.ok) { notify('Erro ao salvar consulta. O backend está rodando?', 'error'); return }
    const created = await resp.json()

    // Enriquecer para exibir imediatamente com nome do paciente
    const paciente = pacientes.find(px => String(px.id) === String(created.paciente_id))
    const display = {
      id: created.id,
      paciente_id: created.paciente_id,
      paciente_nome: paciente ? paciente.nome : `Paciente #${created.paciente_id}`,
      data_consulta: created.data_consulta,
      medico: created.medico,
      observacao: created.observacao,
      criado_em: created.criado_em
    }
    setConsultas(prev => [display, ...prev]);
    notify('Consulta salva com sucesso!', 'success')

    setC({ paciente_id: '', data_consulta: '', medico: '', observacao: '' })
  }

  return (
    <>
      {toast && (
        <div className={`toast toast-${toast.type}`} role="status">{toast.text}</div>
      )}
      <div className="container">
      <nav className="nav">
        <div className="brand">
          <div className="logo" />
          <span>Gestão de Prontuários</span>
        </div>
        <small>React + Node + Postgres • Docker</small>
      </nav>

      <div className="hero">
        <h1>Registro de Pacientes e Consultas</h1>
        <p className="muted">Inclua pacientes, agende consultas e visualize tudo em tempo real.</p>
      </div>

      <section className="grid">
        <div className="card">
          <h2>Novo Paciente</h2>
          <form onSubmit={addPaciente}>
            <input placeholder="Nome *" value={p.nome} onChange={e => setP({ ...p, nome: e.target.value })} required />
            <input placeholder="Idade" type="number" min="0" value={p.idade} onChange={e => setP({ ...p, idade: e.target.value })} />
            
            <input placeholder="E-mail" value={p.email} onChange={e => setP({ ...p, email: e.target.value })} />
            
            <input 
              placeholder="Telefone (XX) XXXXX-XXXX" 
              value={p.telefone} 
              onChange={e => {
                setP({ ...p, telefone: aplicarMascaraTelefone(e.target.value) });
              }} 
            />
            
            <button type="submit">Salvar Paciente</button>
          </form>
        </div>

        <div className="card">
          <h2>Agendar Consulta</h2>
          <form onSubmit={addConsulta}>
            <select value={c.paciente_id} onChange={e => setC({ ...c, paciente_id: e.target.value })} required>
              <option value="">Selecione o Paciente *</option>
              {pacientes.map(px => <option key={px.id} value={px.id}>{px.nome}</option>)}
            </select>

            <select value={c.data_consulta} onChange={e => setC({ ...c, data_consulta: e.target.value })} required>
              <option value="">Selecione Data/Hora *</option>
              {horarios.map(h => {
                const isPast = new Date(h) < new Date();
                return (
                <option key={h} value={h} disabled={isPast}>
                  {new Date(h).toLocaleString()}{isPast ? " (indisponível)" : ""}
                </option>
              )})}
            </select>

            <select value={c.medico} onChange={e => setC({ ...c, medico: e.target.value })}>
              <option value="">Especialidade</option>
              {ESPECIALIDADES.map(sp => <option key={sp} value={sp}>{sp}</option>)}
            </select>

            <input placeholder="Observação" value={c.observacao} onChange={e => setC({ ...c, observacao: e.target.value })} />
            <button type="submit">Salvar Consulta</button>
          </form>
        </div>

        <div className="card">
          <h2>Pacientes <span className="badge">{pacientes.length}</span></h2>
          {pacientes.length === 0 && <p className="muted">Nenhum paciente cadastrado.</p>}
          <div className="list">
            {pacientes.map(px => (
              <div className="item" key={px.id}>
                <strong>{px.nome}</strong> {px.idade ? `— ${px.idade} anos` : ''}
                {px.email ? ` • ${px.email}` : ''}
                {px.telefone ? ` • ${px.telefone}` : ''}
              </div>
            ))}
          </div>
        </div>

        <div className="card">
          <h2>Consultas <span className="badge">{consultas.length}</span></h2>
          {consultas.length === 0 && <p className="muted">Nenhuma consulta registrada.</p>}
          <div className="list">
            {consultas.map(cx => (
              <div className="item" key={cx.id}>
                <strong>{cx.paciente_nome}</strong> — {new Date(cx.data_consulta).toLocaleString()}
                {cx.medico ? ` • ${cx.medico}` : ''}
                {cx.observacao ? ` • ${cx.observacao}` : ''}
              </div>
            ))}
          </div>
        </div>
      </section>

      <div className="footer">© {new Date().getFullYear()} Gestão de Prontuários</div>
    </div>
    </>
  )
}