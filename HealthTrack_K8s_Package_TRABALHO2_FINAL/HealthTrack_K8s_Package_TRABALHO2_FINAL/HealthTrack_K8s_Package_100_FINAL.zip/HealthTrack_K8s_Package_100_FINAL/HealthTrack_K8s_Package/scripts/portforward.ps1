kubectl -n frontend port-forward svc/frontend-svc 8080:80
